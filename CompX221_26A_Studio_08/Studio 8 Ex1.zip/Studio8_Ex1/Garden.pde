class Garden
{
  
}
