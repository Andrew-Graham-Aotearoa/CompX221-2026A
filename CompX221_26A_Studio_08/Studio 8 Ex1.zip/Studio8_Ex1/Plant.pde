class Plant extends GardenObject
{
  
  private int _size;

  
  public boolean isClicked(int x, int y)
  {
    if (pow(x - _centre.x, 2) + pow(y - _centre.y, 2) < pow(_size/2, 2))
    {
      _isSelected = true;
      return true; 
    }
    else
    {
      return false; 
    }
  }
  
  
}
