abstract class GardenObject
{
  
}
