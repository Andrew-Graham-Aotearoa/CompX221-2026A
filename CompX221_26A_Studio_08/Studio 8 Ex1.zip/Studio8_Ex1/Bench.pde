class Bench extends GardenObject
{
  private int _width;
  private int _height;
  
  
  public boolean isClicked(int x, int y)
  {
    if (x >= _centre.x - _width/2 && x <= _centre.x + _width/2 &&
        y >= _centre.y - _height/2 && y <= _centre.y + _height/2)
    {
       _isSelected = true;
       return true;
    }
    else
    {
       return false; 
    }
  }
}
