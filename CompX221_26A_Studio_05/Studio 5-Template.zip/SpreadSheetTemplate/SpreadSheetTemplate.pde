

//Variables for testing the cell classes
//TextCell t1;

//NumericCell n1;

// Setup method
void setup()
{
  
  // Size the sketch (don't change)
  size(600,600);
  
  
  
  //Create a new text cell object to test the TextCell class
  //t1 = new TextCell(200, 400,300, 100,50,"Name");
  
  //Create a new numeric cell object to test the NumericCell class
  //n1 = new NumericCell(50,50,300,100,50,13.0,2);
  
  
}

// Draw method
void draw()
{
  // White background
  background(255);
  
  //Draw the text cell
  //t1.drawCell();
  
  //Draw the numeric cell
  //n1.drawCell();
  
  
}
